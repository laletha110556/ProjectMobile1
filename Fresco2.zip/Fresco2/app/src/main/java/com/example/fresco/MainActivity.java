package com.example.fresco;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private SimpleDraweeView sdvImage;
    private SimpleDraweeView roundBorderImage;
    private SimpleDraweeView circleImage;


    private void findViews() {
        button =  findViewById(R.id.button);
        sdvImage =  findViewById(R.id.sdv_image);
        roundBorderImage =  findViewById(R.id.round_border);
        circleImage =  findViewById(R.id.circle);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fresco.initialize(this);
        setContentView(R.layout.view);
        findViews();

        final Uri imageUri = Uri.parse("https://scontent.fbkk14-1.fna.fbcdn.net/v/t31.0-8/s960x960/26170572_774771252711175_3606295064070710269_o.jpg?_nc_cat=111&_nc_eui2=AeEWc2e16RglyswZy5aUZKiI0x3MhEViwhT-gcesKKxH_sOcfC4y2NPZ3Imk0533Nrhpnrkfh7MQp3y9RXqX_ksunIVPYjhDq-xBDIQ75hVCDQ&_nc_oc=AQkv527hYn54uLnrdGQ4tr_2AUE7X98i4Yoxto2pmp3ONuqv-fgNBm_Q8W0_cbriOtM&_nc_ht=scontent.fbkk14-1.fna&oh=2f0b95aaa1a1983bd39830997099d5f1&oe=5E5DEA8E");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sdvImage.setImageURI(imageUri);
                roundBorderImage.setImageURI(imageUri);
                circleImage.setImageURI(imageUri);

            }
        });
    }
}
