package com.example.glide;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {
    ImageView im1;
    Button bt1;
    Button bt2;
    Button bt3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ImageView im1 = findViewById(R.id.imageView);
        Button bt1 = findViewById(R.id.button);
        Button bt2 = findViewById(R.id.button2);
        Button bt3 = findViewById(R.id.button3);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = "https://scontent.fbkk14-1.fna.fbcdn.net/v/t31.0-8/s960x960/26170572_774771252711175_3606295064070710269_o.jpg?_nc_cat=111&_nc_eui2=AeEWc2e16RglyswZy5aUZKiI0x3MhEViwhT-gcesKKxH_sOcfC4y2NPZ3Imk0533Nrhpnrkfh7MQp3y9RXqX_ksunIVPYjhDq-xBDIQ75hVCDQ&_nc_oc=AQkv527hYn54uLnrdGQ4tr_2AUE7X98i4Yoxto2pmp3ONuqv-fgNBm_Q8W0_cbriOtM&_nc_ht=scontent.fbkk14-1.fna&oh=2f0b95aaa1a1983bd39830997099d5f1&oe=5E5DEA8E";

                Glide.with(MainActivity.this)
                        .load(url)
                        .centerCrop()
                        .placeholder(R.drawable.ic_launcher_foreground)
                        .into(im1);
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = "https://scontent.fbkk14-1.fna.fbcdn.net/v/t31.0-8/s960x960/26170572_774771252711175_3606295064070710269_o.jpg?_nc_cat=111&_nc_eui2=AeEWc2e16RglyswZy5aUZKiI0x3MhEViwhT-gcesKKxH_sOcfC4y2NPZ3Imk0533Nrhpnrkfh7MQp3y9RXqX_ksunIVPYjhDq-xBDIQ75hVCDQ&_nc_oc=AQkv527hYn54uLnrdGQ4tr_2AUE7X98i4Yoxto2pmp3ONuqv-fgNBm_Q8W0_cbriOtM&_nc_ht=scontent.fbkk14-1.fna&oh=2f0b95aaa1a1983bd39830997099d5f1&oe=5E5DEA8E";

                Glide.with(MainActivity.this)
                        .load(url)
                        .fitCenter()
                        .placeholder(R.drawable.ic_launcher_foreground)
                        .into(im1);
            }
        });
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = "https://scontent.fbkk14-1.fna.fbcdn.net/v/t31.0-8/s960x960/26170572_774771252711175_3606295064070710269_o.jpg?_nc_cat=111&_nc_eui2=AeEWc2e16RglyswZy5aUZKiI0x3MhEViwhT-gcesKKxH_sOcfC4y2NPZ3Imk0533Nrhpnrkfh7MQp3y9RXqX_ksunIVPYjhDq-xBDIQ75hVCDQ&_nc_oc=AQkv527hYn54uLnrdGQ4tr_2AUE7X98i4Yoxto2pmp3ONuqv-fgNBm_Q8W0_cbriOtM&_nc_ht=scontent.fbkk14-1.fna&oh=2f0b95aaa1a1983bd39830997099d5f1&oe=5E5DEA8E";

                Glide.with(MainActivity.this)
                        .load(url)
                        .circleCrop()
                        .placeholder(R.drawable.ic_launcher_foreground)
                        .into(im1);
            }
        });
    }
}
